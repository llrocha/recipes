//
// daytime_server.cpp
// ~~~~~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2018 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#include <set>
#include <ctime>
#include <string>
#include <iostream>
#include <iostream>
#include <exception>
#include <boost/asio.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/xml_parser.hpp>
#include <boost/filesystem/convenience.hpp>
//#include <boost/foreach.hpp>
using boost::asio::ip::tcp;


struct load_config
{
    int m_port;
    int m_size;
    void load(const std::string &filename);
    void save(const std::string &filename);
};


void load_config::load(const std::string &filename)
{
    boost::property_tree::ptree tree;

    boost::property_tree::read_xml(filename, tree);

    m_port = tree.get("config.port", 0);

    m_size = tree.get("config.size", 0);
}


void load_config::save(const std::string &filename)
{
    boost::property_tree::ptree tree;

    tree.put("config.port", m_port);
    tree.put("config.size", m_size);
    
    boost::property_tree::write_xml(filename, tree);
}

int main()
{
  try
  {
    char c;
    int count;
    std::string filename;
    boost::asio::io_context io_context;

    load_config config;
    config.load("config.xml");

    std::cout << "Success config loaded..." << std::endl;
    std::cout << "Listening on port: " << config.m_port << std::endl;
    std::cout << "Max file size: " << config.m_size << std::endl;

    tcp::endpoint endpoint(tcp::v4(), config.m_port);
    tcp::acceptor acceptor(io_context, endpoint);

    while(1)
    {
      std::ofstream fd;
      tcp::iostream stream;
      boost::system::error_code ec;
      acceptor.accept(stream.socket(), ec);
      if (!ec)
      {
        stream << config.m_size << std::endl;
        std::getline(stream, filename);
        std::cout << filename << std::endl;
        fd.open(filename.c_str(), std::ios::binary);
        if(fd) {
          count = config.m_size;
          while(stream.read(&c, sizeof(c))) {
            fd << c;
            count--;
            if(count == 0)
              break;
          }
          fd.close();
        } else
          throw "Unable to open file";
        
      }
    }
  }
  catch (std::exception& e)
  {
    std::cerr << e.what() << std::endl;
  }

  return 0;
}
