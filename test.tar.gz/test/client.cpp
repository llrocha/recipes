#include <string>
#include <iostream>
#include <fstream>
#include <boost/asio.hpp>
#include <boost/filesystem/convenience.hpp>

using boost::asio::ip::tcp;

int main(int argc, char* argv[])
{
  char c;
  int max_size;
  std::string line;
  std::string filename;
  std::string extension;
  std::ifstream fd;
  try
  {
    if (argc != 4)
    {
      std::cerr << "Usage: client <host> <port> <filename>" << std::endl;
      return 1;
    }

    tcp::iostream s(argv[1], argv[2]);
    if (!s)
    {
      std::cout << "Unable to connect: " << s.error().message() << std::endl;
      return 1;
    }

    filename = boost::filesystem::basename(argv[3]);
    extension = boost::filesystem::extension(argv[3]);

    //Max Size
    std::getline(s, line);
    max_size = std::atoi(line.c_str());
    std::cout << "Max file size: " << max_size << std::endl;

    s << filename << extension << std::endl;

    //Open file
    fd.open(argv[3], std::ios::binary);
    if(fd) {
      //Send file
      while (fd.read(&c, sizeof(c))) {
        s << c;
      }
      fd.close();
    } else
      throw "Unable to open file";

  }
  catch (std::exception& e)
  {
    std::cout << "Exception: " << e.what() << std::endl;
  }

  return 0;
}
